# mindful
mind full is a website designed specifically with consideration of people with learning disabilities
it make very simplified notes and is able to answer questions based on it.

# installations
this requires installation of `ollama` for local LLms (its safe)

after installation of `ollama` we have to install local llm namely `mistral`
```cmd
ollama pull mistral
```

and then install requirements in python
```cmd
pip install -r "requirements.txt"
```

# contributed by
* Shaksham Dutt
* Mohd Zaid
* Vatsalya Bhadaurya
* Naman Jain
